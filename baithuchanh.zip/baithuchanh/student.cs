﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5_Bai1
{
    class Student : Person
    {
        // thuoc tinh
        private string chuyenNganh;

        // phuong thuc
        public string getChuyenNganh()
        {
            return chuyenNganh;
        }
        //1. Phuong thuc khoi tao khong tham so
        public Student()
        {
            chuyenNganh = "";
        }

        //2. Phuong thuc khoi tao co tham so
        public Student(string ten, int tuoi, string chuyenNganh) : base(ten, tuoi)
        {
            this.chuyenNganh = chuyenNganh;
        }

        //3. ghi de phuong thuc nhap du lieu cua lop Person
        public override void nhapDuLieu()
        {
            base.nhapDuLieu();// goi phuong thuc nhap du lieu cua lop Person (lop cha)
            Console.Write("Nhap chuyen nganh: ");
            chuyenNganh = Console.ReadLine();
        }

        //4. ghi de phuong thuc hien thi cua lop Person
        public override void hienThi()
        {
            base.hienThi();// goi phuong thuc hien thi cua lop Person
            Console.Write(", chuyen nganh: " + chuyenNganh);
        }


        public static string getTen(string hoVaTen)
        {
            // Nguyen Van Tuan
            // Nguyen 0
            // Van 1
            // Tuan 2
            string[] hoTen = hoVaTen.Split(" ");// su dung phuong thuc Split() trong lop string de tach ten theo dau cach
            string ten = hoTen[hoTen.Length-1];// lay phan tu cuoi cung trong mang hoTen --> ten
            return ten;
        }
    }
}
 
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C5_Bai1
{
    class Person
    {
        // thuoc tinh
        private string ten;
        private int tuoi;

        // phuong thuc
        public string getHoTen()
        {
            return ten;
        }
        //1. phuong thuc khoi tao khong tham so
        public Person()
        {
            ten = "";
            tuoi = 1;
        }

        //2. Phuong thuc khoi tao co tham so
        public Person(string ten, int tuoi)
        {
            this.ten = ten;
            this.tuoi = tuoi;
        }

        //3. Phuong thuc nhap du lieu
        public virtual void nhapDuLieu()
        {
            Console.Write("Nhap ho ten: ");
            ten = Console.ReadLine();
            Console.Write("Nhap tuoi: ");
            tuoi = int.Parse(Console.ReadLine());
        }

        // 4. Hien thi thong tin
        public virtual void hienThi()
        {
            Console.Write("\nHo ten: " + ten + ", tuoi: " + tuoi);
        }
    }
}

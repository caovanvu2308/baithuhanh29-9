﻿using System;
using System.Collections.Generic;

namespace C5_Bai1
{
    class Program
    {
        static void Main(string[] args)
        {
            //1. Nhap thong tin cho n sinh vien
            List<Student> dssv = new List<Student>();
            /*int n;// so luong sv
            Console.Write("Nhap so luong sinh vien can quan li: ");
            n = int.Parse(Console.ReadLine());

            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("Nhap thong tin sinh vien thu " + (i + 1));
                Student st = new Student();
                st.nhapDuLieu();
                dssv.Add(st);
            }*/
            dssv.Add(new Student("Nguyen Van Tuan", 25, "CNTT"));
            dssv.Add(new Student("Nguyen Van Tuan Anh", 20, "CNTT"));
            dssv.Add(new Student("Nguyen Van An", 22, "Tieng Anh"));
            dssv.Add(new Student("Nguyen Van Thinh", 20, "Hoa Hoc"));
            dssv.Add(new Student("Nguyen Van Dat", 25, "CNTT"));

            //2. dem sinh vien thuoc chuyen nganh cntt
            int dem = 0;
            Console.WriteLine("Cac sinh vien thuoc chuyen nganh CNTT la");
            foreach(Student sv in dssv)
            {
                if (sv.getChuyenNganh().Equals("CNTT"))
                {
                    dem++;
                    sv.hienThi();
                }
            }
            Console.WriteLine("\nCo " + dem + " sinh vien thuoc chuyen nganh CNTT");
            
            // 3. Tim sv ten "Tuan" hoac "Anh"
            Console.WriteLine("\nCac sinh vien co ten \"Tuan\" hoac \"Anh\" la: ");
            foreach(Student sv in dssv)
            {
                if(Student.getTen(sv.getHoTen()).Equals("Tuan") ||
                    Student.getTen(sv.getHoTen()).Equals("Anh")){
                    sv.hienThi();
                }
            }

        }
    }
}
